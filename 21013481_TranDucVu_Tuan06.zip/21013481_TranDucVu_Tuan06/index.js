const express =  require("express");
const AWS = require("aws-sdk");
const multer = require("multer");
const app = express();
const upload = multer();

app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use(upload.fields([]));

app.use(express.static("./views"));
app.set("view engine", "ejs");

AWS.config.update({
    region: "ap-southeast-1",
    accessKeyId: "AKIAQ3LTMVZSHSNX45QZ",
    secretAccessKey: "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"
});

const TableName = "SanPham";
const dynamodb = new AWS.DynamoDB();
const docClient = new AWS.DynamoDB.DocumentClient();

app.get("/", (req, res) => {
    try {
        dynamodb.scan({
            TableName,
        },(err, data) => {
            if (err) res.send("error");

            res.render("index", {
                products: data.Items
            })

        })
    } catch (error) {
        res.send("error");
    }
})


app.post("/", (req, res) => {
    try {
        const {ma_sp, ten_sp, so_luong} = req.body;

        docClient.put({
            TableName,
            Item: {
                ma_sp,
                ten_sp,
                so_luong: parseInt(so_luong),
            }
        }, (err, data)=>{
            if(err) res.send("error");
            res.redirect("/");
        });
    } catch (error) {
        res.send("error");
    }
})

app.post("/delete", (req, res) => {
    try {
        const {ma_sp} = req.body;

        docClient.delete({
            TableName,
            Key: {
                ma_sp
            }
        }, (err, data)=>{
            if(err) res.send('error');
            res.redirect("/")
        });
    } catch (error) {
        res.send("error");
    }
})




app.listen(3000, () => {
    console.log("App is running on port 3000")
})